
public enum Token { nullToken, 
	Ident, Integer, Real, Plus, Minus, Mult, Divd, Equal, 
	Lparen, Rparen, Print, Literal,
	Ifsym, Whilesym, Elsesym,
	Operand, Constant,
	eol, eof
}
