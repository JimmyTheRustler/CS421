
public class Statement {
	Token stmt;
	Statement next;
}
