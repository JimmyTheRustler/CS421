
public class SymbolEntry {
	String name;
	double value;
}
