
public class AssignmentStmt extends Statement{
	ArithmeticNode expression;
}
